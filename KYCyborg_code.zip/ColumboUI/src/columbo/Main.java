package columbo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter.DefaultHighlightPainter;
import javax.swing.text.Highlighter;

import columbo.webservice.Controller;
import columbo.webservice.IssueElement;
import columbo.webservice.IssuesResponse;
import columbo.webservice.Server;

public class Main extends JFrame{
	
	private static JTextArea editorPane;
	private static JTextArea results;
	private static DefaultHighlightPainter highlightPainter;
	
	 public Main() {
		 Server server = new Server();
		 server.load();
		 initUI();
    }

    private void initUI() {
        setTitle("KYCyborg");
        setSize(700, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());
        JPanel panel = new JPanel(new BorderLayout());
        JLabel label = new JLabel("KYCyborg");
        label.setFont(new Font("Calibri", Font.PLAIN, 36));
        panel.add(label, BorderLayout.PAGE_START);
        Dimension d = new Dimension(400, 300);
        panel.setPreferredSize(d);
        panel.setMinimumSize(d);
        panel.setMaximumSize(d);
        editorPane = new JTextArea();
        editorPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        editorPane.setLineWrap(true);
        editorPane.setWrapStyleWord(true);
        
        results = new JTextArea();
        results.setBackground(Color.yellow);
        panel.add(results, BorderLayout.PAGE_END);
        Dimension d2 = new Dimension(100, 300);
//        results.setPreferredSize(d2);
//        results.setMinimumSize(d2);
        results.setLineWrap(true);
        results.setWrapStyleWord(true);
        
        highlightPainter = new DefaultHighlightPainter(Color.RED);
        
        editorPane.getDocument().addDocumentListener(new DocumentListener() {
			@Override
			public void removeUpdate(DocumentEvent e) {
				onChange();
			}
			
			@Override
			public void insertUpdate(DocumentEvent e) {
				onChange();
			}
			
			@Override
			public void changedUpdate(DocumentEvent e) {
				onChange();
			}
		});
        
        panel.add(editorPane, BorderLayout.CENTER);
        add(panel);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
        	Main main = new Main();
            main.setVisible(true);
        });
    }
    
    public static void onChange() {
    	IssuesResponse response = Controller.runRealData(editorPane.getText());
    	Highlighter highlighter = editorPane.getHighlighter();
    	highlighter.removeAllHighlights();
    	results.setText("");
    	for(IssueElement ie : response.getIssues()) {
    		try {
    			results.setText(ie.getMessage());
				highlighter.addHighlight(ie.getCharBeginning(), ie.getCharEnd(), highlightPainter);
			} catch (BadLocationException e) {
				e.printStackTrace();
			}
    	}
    	
    }
}
