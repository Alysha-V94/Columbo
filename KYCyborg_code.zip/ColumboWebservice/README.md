# Stanford Core NLP Example
