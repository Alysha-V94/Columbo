package columbo;

public class Attribute {
	public String value;
	public int charBeginning;
	public int charEnd;
	
	public Attribute(String value, int charBeginning, int charEnd) {
		this.value = value;
		this.charBeginning = charBeginning;
		this.charEnd = charEnd;
	}
}