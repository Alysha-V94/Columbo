package columbo;

import java.util.Set;

import columbo.webservice.IssueElement;

public interface IssueIdentifier {

	public boolean identifyIssue(Object valueToCheck, Set<Object> values);

	public String getMessage();	
	
}
