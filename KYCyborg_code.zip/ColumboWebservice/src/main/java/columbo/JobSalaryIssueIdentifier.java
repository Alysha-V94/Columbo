package columbo;

import java.util.Set;

public class JobSalaryIssueIdentifier implements IssueIdentifier{

	String message = "Salary is too far away from the average salary of this position";
	String position;
			
	@Override
	public boolean identifyIssue(Object salaryToCheck, Set<Object> salarySet) {
		Integer total = 0;
		for(Object o : salarySet) {
			total += (Integer) o;
		}
		double average = total.doubleValue() / salarySet.size();
		Integer current = (Integer) salaryToCheck;
		if(current > average * 1.5 || current < average * 0.5) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public String getMessage() {
		return "Salary is too far away from the average salary of this position";
	}
	
}
