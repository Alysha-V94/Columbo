package columbo;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import columbo.nlp.TokenAnalyser;

import java.util.Set;

public class PepAttributes {

	private Map<Class<? extends TokenAnalyser<?>>, Attribute> attributes = new HashMap<>();
	
	public void addAttribute(Class<? extends TokenAnalyser<?>> key, String value, int charBeginning, int charEnd) {
		attributes.put(key, new Attribute(value, charBeginning, charEnd));
	}
	
	public String get(Class<? extends TokenAnalyser<?>> key) {
		return attributes.get(key).value;
	}
	
	public int getCharBeginning(Class<? extends TokenAnalyser<?>> key) {
		return attributes.get(key).charBeginning;
	}
	
	public int getCharEnd(Class<? extends TokenAnalyser<?>> key) {
		return attributes.get(key).charEnd;
	}
	
	public Set<Entry<Class<? extends TokenAnalyser<?>>, Attribute>> entrySet(){
		return attributes.entrySet();
	}
}
