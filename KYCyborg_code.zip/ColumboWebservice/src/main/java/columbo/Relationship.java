package columbo;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import columbo.nlp.TokenAnalyser;
import columbo.webservice.IssueElement;
import edu.stanford.nlp.util.Pair;

public class Relationship<S extends TokenAnalyser<?>, T extends TokenAnalyser<?>> {

	private S keyAnalyser;
	private T valueAnalyser;
	private Map<Object, Set<Object>> attributeStore = new HashMap<>();
	private Set<IssueIdentifier> issueIdentifiers = new HashSet<>();
	
	public Relationship(S keyAnalyser, T valueAnalyser) {
		this.keyAnalyser = keyAnalyser;
		this.valueAnalyser = valueAnalyser;
	}
	
	public void addIssueIdentifier(IssueIdentifier issueIdentifier) {
		issueIdentifiers.add(issueIdentifier);
	}
	
	public void process(PepAttributes pepAttributes) {
		Pair<Object, Object> pair = getKeyAndValue(pepAttributes);
		if(pair!=null) {
			if(pair.first!=null && pair.second!=null) {
				if(!attributeStore.containsKey(pair.first)) {
					attributeStore.put(pair.first, new HashSet<>());
				}
				attributeStore.get(pair.first).add(pair.second);
			}
		}
	}
	
	public Pair<Object, Object> getKeyAndValue(PepAttributes pepAttributes){
		try {
			Object thisKey = null;
			Object thisValue = null;
			for(Entry<Class<? extends TokenAnalyser<?>>, Attribute> entry : pepAttributes.entrySet()) {
				if(entry.getKey().equals(keyAnalyser.getClass())) {
					thisKey = keyAnalyser.toObject(entry.getValue().value);
				} else if(entry.getKey().equals(valueAnalyser.getClass())) {
					thisValue = valueAnalyser.toObject(entry.getValue().value);
				}
			}
			if(thisKey==null||thisValue==null) {
				return null;
			}
			return new Pair<Object, Object>(thisKey, thisValue);
		} catch (Exception e) {
			return null;
		}
	}
	
	public IssueElement identifyIssue(PepAttributes pepAttributes) {
		Pair<Object, Object> pair = getKeyAndValue(pepAttributes);
		if(pair!=null) {
			if(attributeStore.get(pair.first)!=null) {
				for(IssueIdentifier issueIdentifier : issueIdentifiers) {
					boolean issue = issueIdentifier.identifyIssue(pair.second, attributeStore.get(pair.first));
					if(issue) {
						return new IssueElement(pepAttributes.getCharBeginning((Class<? extends TokenAnalyser<?>>) valueAnalyser.getClass()), 
								pepAttributes.getCharEnd((Class<? extends TokenAnalyser<?>>) valueAnalyser.getClass()), issueIdentifier.getMessage(), pair.second.toString());
					}
				}
				return null;
			} 
		}
		return null;
	}
}
