package columbo.nlp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.google.cloud.language.v1beta2.AnalyzeEntitiesRequest;
import com.google.cloud.language.v1beta2.ClassificationCategory;
import com.google.cloud.language.v1beta2.ClassifyTextResponse;
import com.google.cloud.language.v1beta2.Document;
import com.google.cloud.language.v1beta2.EncodingType;

import columbo.webservice.Server;

@Service
public class GoogleNLPService {
	
//	public List<String> getCategories(String text){
//		List<String> categories = new ArrayList<>();
//		//google language
//		Document googleDoc = Document.newBuilder().setContent(text).setType(Document.Type.PLAIN_TEXT).build();
//		
//		AnalyzeEntitiesRequest request = AnalyzeEntitiesRequest.newBuilder()
//				.setDocument(googleDoc)
//				.setEncodingType(EncodingType.UTF16)
//				.build();
//		
////				AnalyzeEntitiesResponse response = Server.getLanguageServerClient().analyzeEntities(request);
//		ClassifyTextResponse classifyTextResponse = Server.getLanguageServerClient().classifyText(googleDoc);
//		List<ClassificationCategory> categoriesList = classifyTextResponse.getCategoriesList();
//		for(ClassificationCategory category : categoriesList) {
//			categories.add(category.getName());
//		}
//		return categories;
//	}
	
}
