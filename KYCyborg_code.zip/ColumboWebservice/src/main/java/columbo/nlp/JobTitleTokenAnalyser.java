package columbo.nlp;

import edu.stanford.nlp.ling.CoreLabel;

public class JobTitleTokenAnalyser implements TokenAnalyser<String>{
	
	private static final String ANALYSER_NAME = "JOB_TITLE";
	
	@Override
	public String getAnalyserName() {
		return ANALYSER_NAME;
	}

	@Override
	public boolean process(CoreLabel token) {
		Integer columboInt = token.get(JobTitleAnnotation.class);
		return (columboInt!=null && columboInt.equals(1));
	}

	@Override
	public Class<String> getDataType() {
		return String.class;
	}
	
	@Override
	public String toObject(String string) {
		if(string==null) {
			return null;
		}
		return string.toLowerCase();
	}
}