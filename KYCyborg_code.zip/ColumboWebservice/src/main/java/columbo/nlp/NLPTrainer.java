package columbo.nlp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.cloud.language.v1beta2.ClassificationCategory;
import com.google.cloud.language.v1beta2.AnalyzeEntitiesRequest;
import com.google.cloud.language.v1beta2.Document;
import com.google.cloud.language.v1beta2.EncodingType;
import com.google.cloud.language.v1beta2.AnalyzeEntitiesResponse;
import com.google.cloud.language.v1beta2.ClassifyTextResponse;

import columbo.PepAttributes;
import columbo.Relationship;
import columbo.webservice.Server;
import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.util.CoreMap;

public class NLPTrainer {

	private StanfordCoreNLP pipeline;
	private Set<TokenAnalyser<?>> tokenAnalysers = new HashSet<>();
	private Map<Class<? extends TokenAnalyser<?>>, TokenAnalyser<?>> tokenAnalysersMap = new HashMap<>();
	private Set<Relationship<?, ?>> relationships = new HashSet<>();
//	private Map<String, Set<Integer>> salaryMap = new HashMap<>();

	public NLPTrainer(StanfordCoreNLP pipeline) {
		this.pipeline = pipeline;
	}

	@SuppressWarnings("unchecked")
	public void addTokenAnalyser(TokenAnalyser<?> tokenAnalyser) {
		tokenAnalysers.add(tokenAnalyser);
		tokenAnalysersMap.put((Class<? extends TokenAnalyser<?>>) tokenAnalyser.getClass(), tokenAnalyser);
	}

	public void addRelationship(Relationship<?, ?> relationship) {
		relationships.add(relationship);
	}

	public Set<Relationship<?, ?>> getRelationships() {
		return relationships;
	}

	public void consumeTrainingDataFromResource(String resourceName) throws IOException {
		ClassLoader classloader = Thread.currentThread().getContextClassLoader();
		try (InputStream inputStream = classloader.getResourceAsStream(resourceName)) {
			try (InputStreamReader streamReader = new InputStreamReader(inputStream)) {
				try (BufferedReader reader = new BufferedReader(streamReader)) {
					for (String line; (line = reader.readLine()) != null;) {
						consumeTrainingData(line);
					}
				}
			}
		}
	}

	public void consumeTrainingData(String line) {
		List<PepAttributes> pepAttributesList = reviewData(line);
		for(PepAttributes pepAttributes : pepAttributesList) {
			for (Relationship<?, ?> relationship : relationships) {
				relationship.process(pepAttributes);
			}
		}
	}

	@SuppressWarnings("unchecked")
	public List<PepAttributes> reviewData(String line) {
		Annotation document = new Annotation(line);
		pipeline.annotate(document);
		
		//coreNLP
		List<CoreMap> sentences = document.get(CoreAnnotations.SentencesAnnotation.class);
				
		List<PepAttributes> pepAttributeList = new ArrayList<>();
		for (CoreMap sentence : sentences) {
			PepAttributes pepAttributes = new PepAttributes();
			for (CoreLabel token : sentence.get(CoreAnnotations.TokensAnnotation.class)) {
				for (TokenAnalyser<?> tokenAnalyser : tokenAnalysers) {
					if (tokenAnalyser.process(token)) {
						pepAttributes.addAttribute((Class<? extends TokenAnalyser<?>>) tokenAnalyser.getClass(),
								token.get(CoreAnnotations.TextAnnotation.class),
								token.get(CoreAnnotations.CharacterOffsetBeginAnnotation.class),
								token.get(CoreAnnotations.CharacterOffsetEndAnnotation.class));
						// TODO
					}
				}
			}
			pepAttributeList.add(pepAttributes);
		}
		return pepAttributeList;
	}
}
