package columbo.nlp;

import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.ling.CoreLabel;

public class SalaryTokenAnalyser implements TokenAnalyser<Integer>{

	private static final String ANALYSER_NAME = "SALARY";
	private static final String TOKEN_VALUE_MONEY = "MONEY";
	private static final String TOKEN_VALUE_CARDINAL_NUMBER = "CD";
	
	@Override
	public String getAnalyserName() {
		return ANALYSER_NAME;
	}

	@Override
	public boolean process(CoreLabel token) {
		String partOfSpeech = token.get(CoreAnnotations.PartOfSpeechAnnotation.class);
		String namedEntity = token.get(CoreAnnotations.NamedEntityTagAnnotation.class);
		return (namedEntity.equals(TOKEN_VALUE_MONEY) && partOfSpeech.equals(TOKEN_VALUE_CARDINAL_NUMBER));
	}

	@Override
	public Class<Integer> getDataType() {
		return Integer.class;
	}

	@Override
	public Integer toObject(String string) {
		return Integer.parseInt(string);
	}
	
}
