package columbo.nlp;

import edu.stanford.nlp.ling.CoreLabel;

public interface TokenAnalyser<T> {

	public String getAnalyserName();
	
	public boolean process(CoreLabel token);
	
	public Class<T> getDataType();
	
	public T toObject(String string);
}
