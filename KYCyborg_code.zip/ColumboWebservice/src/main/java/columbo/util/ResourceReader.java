package columbo.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;

public class ResourceReader {

	public static Set<String> toSet(String resource) throws IOException{
		Set<String> returnSet = new HashSet<>();
		ClassLoader classloader = Thread.currentThread().getContextClassLoader();
		try(InputStream inputStream = classloader.getResourceAsStream(resource)){
			try(InputStreamReader streamReader = new InputStreamReader(inputStream)){
				try(BufferedReader reader = new BufferedReader(streamReader)){
					for (String line; (line = reader.readLine()) != null;) {
						returnSet.add(line.toLowerCase());
					}
				}
			}
		}
		return returnSet;
	}
	
}
