package columbo.util;

import java.util.Collection;

public class Utils {

	public static String collectionToDelimitedString(Collection<String> set, String delimiter) {
		StringBuilder stringBuilder = new StringBuilder();
		for (String string : set) {
			stringBuilder.append(string);
			stringBuilder.append(delimiter);
		}
		stringBuilder.setLength(stringBuilder.length() - delimiter.length());
		return stringBuilder.toString();
	}

	public static double calculateAverage(Collection<Integer> marks) {
		Integer sum = 0;
		if (!marks.isEmpty()) {
			for (Integer mark : marks) {
				sum += mark;
			}
			return sum.doubleValue() / marks.size();
		}
		return sum;
	}
	
	public static boolean containsIgnoreCase(Collection<String> collection, String string) {
        for (String s : collection) {
            if (string.equalsIgnoreCase(s)) 
            	return true;
        }
        return false;
    }

}
