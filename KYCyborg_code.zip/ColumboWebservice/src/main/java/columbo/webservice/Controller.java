package columbo.webservice;

import java.util.List;

import org.jsoup.Jsoup;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import columbo.PepAttributes;
import columbo.Relationship;
import columbo.nlp.GoogleNLPService;

@RestController
public class Controller {
	
	@Autowired
//	static GoogleNLPService googleNLPservice;

	@RequestMapping(
			method = RequestMethod.GET,
			value = "/",
			produces = MediaType.TEXT_PLAIN_VALUE)
	@ResponseBody
	public ResponseEntity<String> defaultCall() {
		return new ResponseEntity<>("test", HttpStatus.OK);
	}
	
	@SuppressWarnings("unused")
	@RequestMapping(
			method = RequestMethod.POST,
			value = "/post",
			consumes = MediaType.TEXT_PLAIN_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE
			)
	@ResponseBody
	public ResponseEntity<IssuesResponse> postRealData(@RequestBody String data) {
		List<PepAttributes> attributesList = Server.getNLPTrainer().reviewData(
				Jsoup.parse(data).text());
//				StringEscapeUtils.unescapeHtml4(data));
		IssuesResponse response = new IssuesResponse();
		for(PepAttributes attributes : attributesList) {
			for(Relationship<?,?> relationship : Server.getNLPTrainer().getRelationships()){
				IssueElement issueElement = relationship.identifyIssue(attributes);
				if(issueElement!=null) {
					response.addIssue(issueElement);
				}
			}
		}
//		List<String> categories = googleNLPservice.getCategories(data);
//		response.setCategories(categories);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	public static IssuesResponse runRealData(String data) {
		List<PepAttributes> attributesList = Server.getNLPTrainer().reviewData(
				Jsoup.parse(data).text());
//				StringEscapeUtils.unescapeHtml4(data));
		IssuesResponse response = new IssuesResponse();
		for(PepAttributes attributes : attributesList) {
			for(Relationship<?,?> relationship : Server.getNLPTrainer().getRelationships()){
				IssueElement issueElement = relationship.identifyIssue(attributes);
				if(issueElement!=null) {
					response.addIssue(issueElement);
				}
			}
		}
//		List<String> categories = googleNLPservice.getCategories(data);
//		response.setCategories(categories);
		return response;
	}
	
}
