package columbo.webservice;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName(value = "Issue")
public class IssueElement {

	@JsonProperty(value = "CharBeginning")
	private int charBeginning;
	
	@JsonProperty(value = "CharEnd")
	private int charEnd;
	
	@JsonProperty(value = "Message")
	private String message;
	
	@JsonProperty(value = "OffendingTerm")
	private String offendingTerm;
	
	protected IssueElement(){
	}
	
	public IssueElement(int charBeginning, int charEnd, String message, String offendingTerm) {
		this.charBeginning = charBeginning;
		this.charEnd = charEnd;
		this.message = message;
		this.offendingTerm = offendingTerm;
	}

	public int getCharBeginning() {
		return charBeginning;
	}

	public int getCharEnd() {
		return charEnd;
	}

	public String getMessage() {
		return message;
	}

	public String getOffendingTerm() {
		return offendingTerm;
	}	
}
