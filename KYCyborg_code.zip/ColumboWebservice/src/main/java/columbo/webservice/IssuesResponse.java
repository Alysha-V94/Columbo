package columbo.webservice;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

@JsonRootName(value = "Issues")
public class IssuesResponse {

	@JsonProperty(value = "Issues")
	private List<IssueElement> issues = new ArrayList<>();
	
	@JsonProperty(value = "Categories")
	private List<String> categories = new ArrayList<>();
	
	public IssuesResponse() {
	}
	
	public void addIssue(IssueElement issue) {
		issues.add(issue);
	}

	public List<IssueElement> getIssues() {
		return issues;
	}

	public List<String> getCategories() {
		return categories;
	}

	public void setCategories(List<String> categories) {
		this.categories = categories;
	}
}
