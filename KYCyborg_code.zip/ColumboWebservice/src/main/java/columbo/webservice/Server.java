package columbo.webservice;

import java.io.IOException;
import java.util.Properties;
import java.util.Set;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.google.cloud.language.v1beta2.LanguageServiceClient;

import columbo.JobSalaryIssueIdentifier;
import columbo.Relationship;
import columbo.nlp.JobTitleTokenAnalyser;
import columbo.nlp.NLPTrainer;
import columbo.nlp.SalaryTokenAnalyser;
import columbo.util.ResourceReader;
import columbo.util.Utils;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;

@WebListener
public class Server implements ServletContextListener {

	private static NLPTrainer nlpTrainer;
//	private static LanguageServiceClient languageServerClient;

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		load();
	}

	public static void load() {
		// LOAD JOB TITLES
		Set<String> jobTitles = null;
		try {
			jobTitles = ResourceReader.toSet("single_value_job_list.txt");
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}

		Properties props = new Properties();
		props.setProperty("customAnnotatorClass.jobtitle", "columbo.nlp.JobTitleTokenAnnotator");
		props.setProperty("annotators", "tokenize, ssplit, pos, lemma, ner, parse, dcoref, jobtitle");
		props.setProperty("JOB_TITLES_LIST", Utils.collectionToDelimitedString(jobTitles, ","));
		StanfordCoreNLP pipeline = new StanfordCoreNLP(props);

		JobTitleTokenAnalyser jobTitleTokenAnalyser = new JobTitleTokenAnalyser();
		SalaryTokenAnalyser salaryTokenAnalyser = new SalaryTokenAnalyser();

		nlpTrainer = new NLPTrainer(pipeline);
		nlpTrainer.addTokenAnalyser(jobTitleTokenAnalyser);
		nlpTrainer.addTokenAnalyser(new SalaryTokenAnalyser());

		Relationship<JobTitleTokenAnalyser, SalaryTokenAnalyser> jobSalaryRelationship = new Relationship<JobTitleTokenAnalyser, SalaryTokenAnalyser>(
				jobTitleTokenAnalyser, salaryTokenAnalyser);
		jobSalaryRelationship.addIssueIdentifier(new JobSalaryIssueIdentifier());

		nlpTrainer.addRelationship(jobSalaryRelationship);
		try {
			nlpTrainer.consumeTrainingDataFromResource("columbo.txt");
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}

//		try {
//			languageServerClient = LanguageServiceClient.create();
//		} catch (IOException e) {
//			e.printStackTrace();
//			System.exit(0);
//		}
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {

	}

	public static NLPTrainer getNLPTrainer() {
		return nlpTrainer;
	}

//	public static LanguageServiceClient getLanguageServerClient() {
//		return languageServerClient;
//	}
}
