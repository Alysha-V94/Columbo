const verifyQuestionaryForm = (businessBackground) => {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve({
                start: 1,
                end: 2,
                issue: 'issue'
            });
        }, 1000);
    });
};

export default verifyQuestionaryForm;