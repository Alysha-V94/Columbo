import React, { Component } from 'react';
import { connect } from 'react-redux';
import _ from 'lodash';
import tinymce from 'tinymce';

import { getFormElement } from './formGenerator';
import './Questionary.css';

import Input from '../../ui/Input/Input';
import * as actions from '../../../store/actions/index';

class Questionary extends Component {
    state = {
        questionaryForm: {
            name: getFormElement('input', 'text', 'Your Name', 'Name'),
            street: getFormElement('input', 'text', 'Your Street', 'Address'),
            zipCode: getFormElement('input', 'text', 'ZIP CODE', 'ZIP CODE'),
            country: getFormElement('input', 'text', 'Country', 'Country'),
            email: getFormElement('input', 'email', 'Your E-Mail', 'E-Mail'),
            businessBackground: getFormElement('textarea', 'text', 'Your Business Background', 'Business Background')
        },
        tooltip: 'text'
    }

    updateObject = (oldObject, updatedProperties) => {
        const newObject = _.cloneDeep(oldObject);
        return Object.assign(newObject, updatedProperties);
    };

    inputChangedHandler = (event, inputIdentifier) => {
        const updatedFormElement = this.updateObject(this.state.questionaryForm[inputIdentifier], {
            value: event.target.value,
        });
        const updatedQuestionaryForm = this.updateObject(this.state.questionaryForm, {
            [inputIdentifier]: updatedFormElement
        });
        this.setState({ questionaryForm: updatedQuestionaryForm });
    };

    businessBackgroundChangedHandler = (event, inputIdentifier) => {
        this.inputChangedHandler(event, inputIdentifier);
        if (this.state.timeout) {
            clearTimeout(this.state.timeout);
        }
        const value = event.target.value;
        const timeout = setTimeout(() => {
            this.props.onFormSubmitted(value);
            const editor = tinymce.editors[0];
            let content = editor.getContent();
            console.log(this.props.tooltip)
            content = content.replace(this.props.tooltip, `<b>issue</b>`)
            editor.setContent(content);
        }, 2000);
        this.setState({ timeout });
    };

    render() {
        console.log(globalState)
        const inputs = Object.keys(this.state.questionaryForm)
            .map(key => {
                return { id: key, config: this.state.questionaryForm[key] }
            })
            .map(formElement => <Input 
                key={formElement.id}
                elementType={formElement.config.elementType}
                elementConfig={formElement.config.elementConfig}
                value={formElement.config.value}
                label={formElement.config.label}
                elementId={formElement.id}
                changed={formElement.config.label === 'Business Background'
                    ? (event) => this.businessBackgroundChangedHandler(event, formElement.id)
                    : (event) => this.inputChangedHandler(event, formElement.id)} />);

        return (
            <div className='Questionary'>
                <form>
                    {inputs}
                </form>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        tooltip: state.form.tooltipText
    };
};

const mapDispatchToProps = dispatch => {
    return {
        onFormSubmitted: (form) => dispatch(actions.submitForm(form)),
        onKeyChanged: () => dispatch(actions.setKeyChanged()),
        onKeyChangedStartTimeout: () => dispatch(actions.keyChangedStartTimeout())
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(Questionary);