export const getFormElement = (elementType, type, placeholder, label, value) => {
    const formElement = { 
        elementType, 
        elementConfig: { type, placeholder },
        value: value || '',
        validation: {
            required: true
        },
        valid: false,
        touched: false,
        label
    }
    return formElement;
};