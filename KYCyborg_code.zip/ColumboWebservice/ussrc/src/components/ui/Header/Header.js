import React from 'react';

import './Header.css';
import logo from '../../../assets/ubs-logo.png';

const header = (props) => (
    <div className='Header'>
        <img src={logo} className='Logo' alt='logo' /> 
        <div className='PageTitle'>Columbo</div>
    </div>
);

export default header;