import React, { Component } from 'react';
import { Editor } from '@tinymce/tinymce-react';

import './Input.css';

class Input extends Component {

    render() {
        let inputElement = null;
        const inputClasses = ['InputElement'];

        switch (this.props.elementType) {
            case ('input'):
                inputElement = <input 
                    onChange={this.props.changed}
                    className={inputClasses.join(' ')} 
                    { ...this.props.elementConfig } 
                    value={this.props.value} />;
                break;
            case ('textarea'):
                inputElement = <Editor
                    initialValue={this.props.value}
                    init={{
                        toolbar: false,
                        menubar: false,
                        branding: false,
                        resize: false,
                        statusbar: false,
                        plugins: 'link image code',
                    }}
                    onChange={this.props.changed}
                />
                
                // <textarea
                //     id={this.props.id}
                //     onChange={this.props.changed}
                //     className={inputClasses.concat('TextArea').join(' ')} 
                //     { ...this.props.elementConfig } 
                //     value={this.props.value} />;
                break;
            case ('select'):
                inputElement = 
                    <select 
                        onChange={this.props.changed}
                        className={inputClasses.join(' ')}
                        value={this.props.value}>
                        {this.props.elementConfig.options.map(option => (
                            <option key={option.value} value={option.value}>
                                {option.displayValue}
                            </option>
                        ))}
                    </select>
                break;
            default:
                inputElement = <input 
                    onKeyUp={this.props.changed}
                    className={inputClasses.join(' ')} 
                    {...this.props.elementConfig } 
                    value={this.props.value} />;
        }

        return (
            <div className={'Input'}>
                <label className={'Label'}>{this.props.label}  </label>
                {inputElement}
            </div>
        );
    }
}

export default Input;