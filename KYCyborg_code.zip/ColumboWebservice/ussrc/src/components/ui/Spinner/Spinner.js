import React from 'react';

import './Spinner.css';

const spinner = (props) => <div classType='Spinner' />

export default spinner;