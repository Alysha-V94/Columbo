import React from 'react';

import './Tooltip.css';

const tooltip = (props) => (
    <div className='Tooltip'>props.text</div>
);

export default tooltip;