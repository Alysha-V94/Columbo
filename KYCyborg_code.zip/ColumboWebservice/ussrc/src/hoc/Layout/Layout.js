import React, { Component } from 'react';
import { connect } from 'react-redux';

import Questionary from '../../components/content/Questionary/Questionary';
import Header from '../../components/ui/Header/Header';

class Layout extends Component {
    render() {
        return (
            <React.Fragment>
                <Header />
                <Questionary />
            </React.Fragment>
        );
    }
}

const mapStateToProps = state => {
    return {
        verifying: !state.form.verifying
    };
};

export default connect(mapStateToProps)(Layout);