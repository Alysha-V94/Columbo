import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { createStore, applyMiddleware, compose, combineReducers } from 'redux';
import createSagaMiddleware from 'redux-saga';
import { watchForm } from './store/sagas/index';

import './index.css';

import App from './App';
import registerServiceWorker from './registerServiceWorker';
import formReducer from './store/reducers/form';

const composeEnhancers = 
    (process.env.NODE_ENV === 'development' ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ : null) 
    || compose;
const rootReducer = combineReducers({
    form: formReducer
});
const sagaMiddleware = createSagaMiddleware();
const store = createStore(
    rootReducer, 
    composeEnhancers(applyMiddleware(sagaMiddleware)
));

sagaMiddleware.run(watchForm);

const app = (
    <Provider store={store}>
        <App />
    </Provider>
);

ReactDOM.render(app, document.getElementById('root'));
registerServiceWorker();
