import * as actionTypes from './actionTypes';

export const submitForm = (businessBackground) => {
    return {
        type: actionTypes.SUMBIT_FORM,
        businessBackground
    };
};

export const checkTooltip = (tooltip)  => {
    return {
        type: actionTypes.CHECK_TOOLTIP,
        tooltip
    };
};

export const startSubmittingForm = () => {
    return {
        type: actionTypes.SUBMIT_FORM_START
    };
};

export const finishSubmittingForm = (tooltip) => {
    return {
        type: actionTypes.SUBMIT_FORM_FINISH,
        tooltip
    };
};

export const setKeyChanged = () => {
    return {
        type: actionTypes.KEY_CHANGED
    };
};

export const keyChangedStart = () => {
    return {
        type: actionTypes.KEY_CHANGED_START
    };
};

export const keyChangedStartTimeout = () => {
    return {
        type: actionTypes.KEY_CHANGED_START_TIMEOUT
    };
};

