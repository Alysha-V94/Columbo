import _ from 'lodash';

import * as actionTypes from '../actions/actionTypes';

const initialState = {
    verifying: false,
    keyChanged: false,
    keyChangedStartTimeout: false,
    tooltipText: 'issue text',
    tooltip: null
};

const updateObject = (oldObject, updatedProperties) => {
    const newObject = _.cloneDeep(oldObject);
    return Object.assign(newObject, updatedProperties);
};

const submitFormStart = (state) => {
    return updateObject(state, { verifying: true });
};

const submitFormFinish = (state, action) => {
    return updateObject(state, { tooltip: action.tooltip });
};

const keyChangedStart = (state) => {
    return updateObject(state, { keyChanged: true } );
};

const keyChangedStartTimeout = (state) => {
    return updateObject(state, { keyChangedStartTimeout: true })
};

const checkTooltip = (state, action) => {
    if (action.tooltipText) {
        console.log(action.tooltip);
        return updateObject(state, { tooltipText: action.tooltip.issue });
    }
    return state;
};

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case actionTypes.SUBMIT_FORM_START: return submitFormStart(state, action);
        case actionTypes.SUBMIT_FORM_FINISH: return submitFormFinish(state, action);
        case actionTypes.KEY_CHANGED_START: return keyChangedStart(state, action);
        case actionTypes.KEY_CHANGED_START_TIMEOUT: return keyChangedStartTimeout(state, action);
        case actionTypes.CHECK_TOOLTIP: return checkTooltip(state, action);
        default: return state;
    }
}

export default reducer;