import { put } from 'redux-saga/effects'

import verifyQuestionaryForm from '../../async/verifyForm';
import * as actions from '../actions/index';

export function* submitFormSaga(action) {
    yield put(actions.startSubmittingForm())
    const response = yield verifyQuestionaryForm(action.businessBackground);
    yield put(actions.finishSubmittingForm(response));
    if (response.issue) {
        console.log(response.issue);
    }
};