import { takeEvery } from 'redux-saga/effects';

import * as actionTypes from '../actions/actionTypes';
import { submitFormSaga } from './form';

export function* watchForm() {
    yield takeEvery(actionTypes.SUMBIT_FORM, submitFormSaga);
}